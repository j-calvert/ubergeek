
open Stlc2

(* We start with some examples that do not necessarily help you solve
part (e) except to show you how to build and mutate abstract
syntax. You can delete them if you want. *)

(* Here is an example of a function that builds new abstract syntax
every time it is called, but the abstract syntax it builds does not
type-check.  *) 
let make_bad_code () = Apply(ref (Const 9), Const 17)

(* Executing this would raise Stlc2.Unimplemented or Stlc2.TypeError *)
let f() = (Stlc2.typecheck2 (make_bad_code()))

(* Here is an example of a function that uses mutation but (ignoring
typing), keeps the expression equivalent to its input *)
let eta_expand_outermost e =
  match e with
    Apply(r,_) -> r := Lam("z",Int,Apply((ref (!r)), Var("z")))
  | _ -> ()

(* If interpret1 is safe, leave this commented out, else make calling break_a
call interpret1 such that it raises Stlc2.RunTimeError *)
(*let break_a () =*)

(* If interpret2 is safe, leave this commented out, else make calling break_a
call interpret2 such that it raises Stlc2.RunTimeError *)
(*let break_b () =*)

(* If the function returned from Stlc2.typecheck3 is always safe, leave this
commented out, else make calling break_c call a function returned from
Stlc2.typecheck3 such that it raises Stlc2.RunTimeError *)
(*let break_c () =*)

(* If interpret4 is safe, leave this commented out, else make calling break_d 
call interpret4 such that it raises Stlc2.RunTimeError *)
(*let break_d () =*)

